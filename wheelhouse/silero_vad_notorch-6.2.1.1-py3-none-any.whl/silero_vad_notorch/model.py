from .utils_vad import OnnxWrapper


def load_silero_vad(onnx=True, opset_version=16):
    if not onnx:
        raise ValueError(
            "JIT model requires torch which is no longer a dependency. "
            "Use load_silero_vad(onnx=True) instead."
        )

    available_ops = [15, 16]
    if opset_version not in available_ops:
        raise Exception(f'Available ONNX opset_version: {available_ops}')

    if opset_version == 16:
        model_name = 'silero_vad.onnx'
    else:
        model_name = f'silero_vad_16k_op{opset_version}.onnx'
    package_path = "silero_vad_notorch.data"

    try:
        import importlib_resources as impresources
        model_file_path = str(impresources.files(package_path).joinpath(model_name))
    except:
        from importlib import resources as impresources
        try:
            with impresources.path(package_path, model_name) as f:
                model_file_path = f
        except:
            model_file_path = str(impresources.files(package_path).joinpath(model_name))

    model = OnnxWrapper(str(model_file_path), force_onnx_cpu=True)
    return model
